"""Train and evaluate a Random Forest sales forecasting model."""
from pathlib import Path
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from data_preprocessing import load_and_clean

def make_features(df):
    s = df.set_index("Date")["Revenue"].asfreq("D").interpolate()
    X = pd.DataFrame(index=s.index)
    X["day_of_week"] = X.index.dayofweek
    X["day_of_month"] = X.index.day
    X["month"] = X.index.month
    X["quarter"] = X.index.quarter
    X["day_of_year"] = X.index.dayofyear
    X["trend"] = range(len(X))
    X["lag_1"] = s.shift(1)
    X["lag_7"] = s.shift(7)
    X["rolling_mean_7"] = s.shift(1).rolling(7).mean()
    X["rolling_mean_30"] = s.shift(1).rolling(30).mean()
    joined = X.join(s.rename("target")).dropna()
    return joined, s

def main():
    df = load_and_clean()
    table, series = make_features(df)
    split = int(len(table) * 0.8)
    train, test = table.iloc[:split], table.iloc[split:]
    features = [c for c in table.columns if c != "target"]
    model = RandomForestRegressor(n_estimators=250, max_depth=10, min_samples_leaf=3,
                                  random_state=42, n_jobs=-1)
    model.fit(train[features], train["target"])
    pred = model.predict(test[features])
    print("MAE:", round(mean_absolute_error(test["target"], pred), 2))
    print("RMSE:", round(mean_squared_error(test["target"], pred)**0.5, 2))
    print("R2:", round(r2_score(test["target"], pred), 4))
    Path("models").mkdir(exist_ok=True)
    joblib.dump({"model": model, "features": features, "history": series,
                 "last_date": str(series.index.max().date())}, "models/sales_revenue_model.pkl")

if __name__ == "__main__":
    main()
