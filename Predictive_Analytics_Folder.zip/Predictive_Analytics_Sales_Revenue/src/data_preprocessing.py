"""Load and validate the sales dataset."""
from pathlib import Path
import pandas as pd

def load_and_clean(path="dataset/sales_data.csv"):
    df = pd.read_csv(path)
    required = {"Date", "Revenue"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df["Revenue"] = pd.to_numeric(df["Revenue"], errors="coerce")
    df = df.dropna(subset=["Date", "Revenue"]).drop_duplicates(subset=["Date"])
    df = df[df["Revenue"] >= 0].sort_values("Date").reset_index(drop=True)
    return df

if __name__ == "__main__":
    cleaned = load_and_clean()
    print(cleaned.head())
    print(f"Rows after cleaning: {len(cleaned)}")
