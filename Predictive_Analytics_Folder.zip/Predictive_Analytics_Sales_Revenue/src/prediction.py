"""Generate a recursive 30-day revenue forecast."""
import joblib
import pandas as pd

def forecast_next_days(model_path="models/sales_revenue_model.pkl", days=30):
    package = joblib.load(model_path)
    model, features = package["model"], package["features"]
    history = package["history"].copy()
    future_dates = pd.date_range(history.index.max() + pd.Timedelta(days=1), periods=days, freq="D")
    rows = []
    for date in future_dates:
        row = {
            "day_of_week": date.dayofweek, "day_of_month": date.day, "month": date.month,
            "quarter": date.quarter, "day_of_year": date.dayofyear, "trend": len(history),
            "lag_1": history.iloc[-1], "lag_7": history.iloc[-7],
            "rolling_mean_7": history.iloc[-7:].mean(),
            "rolling_mean_30": history.iloc[-30:].mean()
        }
        value = float(model.predict(pd.DataFrame([row])[features])[0])
        rows.append({"Date": date, "Forecast_Revenue": round(value, 2)})
        history.loc[date] = value
    return pd.DataFrame(rows)

if __name__ == "__main__":
    result = forecast_next_days()
    result.to_csv("outputs/next_30_days_forecast.csv", index=False)
    print(result.to_string(index=False))
