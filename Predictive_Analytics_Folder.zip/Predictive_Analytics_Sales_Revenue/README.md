# Predictive Analytics Using Historical Data
## Sales Revenue Forecasting

### Objective
Use historical daily sales data to identify trends and forecast revenue for the next 30 days.

### Dataset
`dataset/sales_data.csv` contains daily sample sales records from 2023-01-01 to 2025-12-31. **This is synthetic educational data, not actual company sales.** Replace it with a real dataset for a real-world analysis.

Columns:
- `Date`: transaction day
- `Units_Sold`: number of units sold
- `Revenue`: daily revenue
- `Cost`: estimated daily cost
- `Profit`: revenue minus cost
- `Promotion`: 1 if a promotion was active, otherwise 0

### Setup
Use Python 3.10+.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

### Run the project
From the project root:

```bash
python src/data_preprocessing.py
python src/model_training.py
python src/prediction.py
```

Or open `notebooks/Predictive_Analytics.ipynb` in Jupyter Notebook and run cells from top to bottom. In the notebook, paths are relative to the notebook folder.

### Model and evaluation
A Random Forest Regressor is trained using date features, lag values, and rolling averages. The final 20% of the timeline is held out as test data. Metrics:
- MAE (Mean Absolute Error)
- RMSE (Root Mean Squared Error)
- R² (coefficient of determination)

The evaluation numbers in `report/Project_Report.pdf` are from this included sample dataset and may change if you replace the dataset or rerun with different settings.

### Outputs
- `outputs/actual_vs_predicted.png`
- `outputs/monthly_sales_trend.png`
- `outputs/future_forecast.png`
- `outputs/next_30_days_forecast.csv`
- `models/sales_revenue_model.pkl`

### Important
This is an academic demonstration. Forecasts are estimates, not guarantees. Check data quality, seasonality, promotions, holidays, and business context before relying on forecasts.
